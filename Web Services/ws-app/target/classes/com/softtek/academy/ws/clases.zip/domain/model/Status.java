package com.softtek.academy.ws.domain.model;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class Status {

    private Long id;

    private String description;

    private String type;


  
}
