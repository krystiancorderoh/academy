package com.softtek.academy.ws.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Uom {
	private String id;
	
	private String description;
	
}
