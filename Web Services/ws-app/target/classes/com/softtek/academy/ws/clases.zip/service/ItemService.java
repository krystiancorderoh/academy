package com.softtek.academy.ws.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.academy.ws.dao.ItemDao;
import com.softtek.academy.ws.domain.model.Item;
import com.softtek.academy.ws.exception.InvalidInputException;
@Service
public class ItemService {
	@Autowired
    private ItemDao itemDao;



    public Item getItem(Long id) throws SQLException {
        return itemDao.findOne(id);
    }
    
    public List<Item> getItemByCategoryId(Long id) throws SQLException {
        return itemDao.findByCategoryId(id);
    }

//    public List<Item> getItems() throws SQLException {
//        return itemDao.findAll();
//    }
//
//    public Item save(ItemDto ItemDto) throws SQLException {
//        validate(ItemDto);
//
//        return itemDao.save(ItemDto);
//    }
//
//    private void validate(ItemDto ItemDto) throws InvalidInputException {
//        if (StringUtils.isBlank(ItemDto.getDescription()) || ItemDto.getStateId() == null) {
//            throw new InvalidInputException("Valid id, description and stateId requiered");
//        }
//
//    }
//
//    public Item update(Long ItemId, ItemDto ItemDto) throws InvalidInputException, SQLException {
//        validate(ItemDto);
//
//        return itemDao.update(ItemId, ItemDto);
//    }
//
//    public void delete(Long ItemId) throws SQLException {
//        itemDao.delete(ItemId);
//    }
}
