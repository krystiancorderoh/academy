package com.softtek.academy.ws.domain.model;

import java.time.LocalDateTime;

import com.softtek.academy.ws.domain.dto.ErrorResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
public class Cart {

    private Long id;

    private User user;

    private Double linesAmount;

    private Status status;

    private String createUser;

    private LocalDateTime createDate;


}
