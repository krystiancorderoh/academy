
public class TaskToUser {

	int idTaskToUser;
	int idTask;
	int idUser;
	int idPriority;
	int idStatus;
	
	public int getIdTaskToUser() {
		return idTaskToUser;
	}
	public void setIdTaskToUser(int idTaskToUser) {
		this.idTaskToUser = idTaskToUser;
	}
	public int getIdTask() {
		return idTask;
	}
	public void setIdTask(int idTask) {
		this.idTask = idTask;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	public int getIdPriority() {
		return idPriority;
	}
	public void setIdPriority(int idPriority) {
		this.idPriority = idPriority;
	}
	public int getIdStatus() {
		return idStatus;
	}
	public void setIdStatus(int idStatus) {
		this.idStatus = idStatus;
	}
	
	
}
