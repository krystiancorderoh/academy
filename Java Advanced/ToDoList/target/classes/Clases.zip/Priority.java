
public class Priority {
	
	int idPriority;
	String name;
	String description;
	
	public int getIdPriority() {
		return idPriority;
	}
	public void setIdPriority(int idPriority) {
		this.idPriority = idPriority;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
